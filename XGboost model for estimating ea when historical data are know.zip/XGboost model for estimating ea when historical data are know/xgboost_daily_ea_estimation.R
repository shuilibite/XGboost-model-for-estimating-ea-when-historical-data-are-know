
library(xgboost)# load xgboost package, make sure you have install.packages('xgboost')
library(lubridate,warn.conflicts = FALSE)    # make sure you have install.packages ('lubridate')
 library(openxlsx) #make sure you have install.packages('openxlsx')


###### load the train data, please modify the file path#########
data_train<-read.xlsx("D:/test/50136train.xlsx")    #please modify the file path here
names(data_train)<-c('date','Tmax','Tmin','RH')
ea_max1=0.6108*exp(17.27*data_train$Tmax/(data_train$Tmax+237.3))
ea_min1=0.6108*exp(17.27*data_train$Tmin/(data_train$Tmin+237.3))
ea1=data_train$RH/(50/ea_max1+50/ea_min1)
data_train[,5]=ea1;
data_train[,6]=(data_train$Tmax+data_train$Tmin)/2
names(data_train)<-c('year','Tmax','Tmin','RH','ea','Tave')

###### load the test data, please modify the file path#########
    data_test<-read.xlsx("D:/test/50136test.xlsx")  #please modify the file path
    data_test[,4]=(data_test[,2]+data_test[,3])/2
    names(data_test)<-c('year','Tmax','Tmin','Tave')#
      train<-data_train             
      test<-data_test
  names(train)<-c('year','Tmax','Tmin','RH','ea','Tave')
  names(test)<-c('year','Tmax','Tmin','Tave')
  trainF<-as.matrix(train$ea);
  trainX<-as.matrix(cbind(train$Tave,train$Tmin));
  names(trainX)<-c("Tave","Tmin")
  testX<-as.matrix(cbind(test$Tave,test$Tmin));
  names(testX)<-c("Tave","Tmin")
    reg.rf<-xgboost(data=trainX, label=trainF, max_depth=3, eta=0.01, nthread =2, nrounds=2000
                  , min_child_weight = 1,subsample =0.6) 
  
  pred1<-predict(reg.rf, trainX)
  pred2<-predict(reg.rf, testX)
     r1<-cbind(data_test,pred2)
  
 write.csv(r1,file=paste("D:/","xgboost_test.csv",sep=""), row.names = F);

